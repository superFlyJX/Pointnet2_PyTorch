from .Indoor3DSemSegLoader import Indoor3DSemSeg
from .ModelNet40Loader import ModelNet40Cls
